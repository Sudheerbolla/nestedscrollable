const fonts = {
  FONT_BOLD: 'ProximaNovaCond-Semibold',
  FONT_LIGHT: 'ProximaNova-Light'
};

module.exports = fonts;
