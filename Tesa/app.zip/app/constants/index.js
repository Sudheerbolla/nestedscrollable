module.exports = {
  COLORS: require('./colors'),
  ICONS: require('./icons'),
  FONTS: require('./font')
};
