const colors = {
  BLUE: '#00a5e5',
  RED: '#e3000e',
  BLUE_LIGHT: '#dcebfa',
  DARK_BLUE: '#003A80',
  DARK_GREY: '#333333',
  LIGHT_GREY: '#dadada',
  BLUE_3: '#C6E2ED',
  BLANK: 'transparent',
  WHITE: '#ffffff',
};

module.exports = colors;
