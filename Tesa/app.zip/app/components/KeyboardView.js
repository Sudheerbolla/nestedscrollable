// import React, {Component} from 'react'
// import {
//   Text,
//   ScrollView
// } from 'react-native'
//
// import {KeyboardRegistry} from 'react-native-keyboard-input';
// KeyboardRegistry.registerKeyboard('MyKeyboardView', () => KeyboardView);
//
// class KeyboardView extends Component {
//   static propTypes = {
//     title: PropTypes.string,
//   };
//   render() {
//     return (
//       <ScrollView>
//         <Text style={{color: 'white'}}>HELOOOO!!!</Text>
//         <Text style={{color: 'white'}}>{this.props.title}</Text>
//       </ScrollView>
//     );
//   }
// }
